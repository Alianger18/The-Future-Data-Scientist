for i in range(n):
    for j in range(n):
        for h in range(n):
            print(i + j + h)
