for i in range(n):
    print(n)
