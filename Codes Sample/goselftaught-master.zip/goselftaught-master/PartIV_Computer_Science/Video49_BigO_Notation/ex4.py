for i in range(n):
    i += 1
    i -= 1
    print(i)
