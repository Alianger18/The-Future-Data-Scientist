for i in range(n):
    for j in range(n):
        print(i + j)
