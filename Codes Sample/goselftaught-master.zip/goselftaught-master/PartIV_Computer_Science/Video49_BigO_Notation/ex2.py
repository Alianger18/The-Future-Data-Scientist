for i in range(100):
    i += 1
    i +- 1
    print(i)
