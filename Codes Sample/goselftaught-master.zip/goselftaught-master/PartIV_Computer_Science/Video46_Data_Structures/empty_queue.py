a_queue = Queue()
print(a_queue.is_empty())
