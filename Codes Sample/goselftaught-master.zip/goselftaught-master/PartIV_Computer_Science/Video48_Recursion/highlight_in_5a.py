if bob < 1:
        print("""No more bottles of beer on the wall. No more 
                 bottles of beer.""")
        return
