$ grep Beautiful zen.txt
