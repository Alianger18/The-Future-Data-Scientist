$ grep -o Beautiful zen.txt
