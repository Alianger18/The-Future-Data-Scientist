$ echo Two too. | grep  -i t[ow]o
