$ echo I love $ | grep  \$
