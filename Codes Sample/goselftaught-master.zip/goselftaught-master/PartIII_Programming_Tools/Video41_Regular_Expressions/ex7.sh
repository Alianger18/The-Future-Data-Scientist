import re


line = "Beautiful is better than ugly."


matches = re.findall("Beautiful", line)


print(matches)
