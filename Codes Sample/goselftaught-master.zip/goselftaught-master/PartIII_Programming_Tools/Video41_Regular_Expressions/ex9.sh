$ grep ^If zen.txt
