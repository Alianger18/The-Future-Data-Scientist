python3 -c "import this"
