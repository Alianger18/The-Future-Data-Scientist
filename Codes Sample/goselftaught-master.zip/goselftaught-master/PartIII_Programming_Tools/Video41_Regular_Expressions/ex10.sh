$ grep idea.$ zen.txt
