$ echo two twoo not too. | grep -o two*
