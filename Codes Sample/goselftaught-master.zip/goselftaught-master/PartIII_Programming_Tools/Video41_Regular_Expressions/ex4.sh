$ grep beautiful zen.txt
