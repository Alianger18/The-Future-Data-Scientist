$ pwd
