$ mkdir tstp
