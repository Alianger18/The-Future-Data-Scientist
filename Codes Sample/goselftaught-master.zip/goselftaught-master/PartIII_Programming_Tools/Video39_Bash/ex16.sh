$ export x=100
$ echo $x
