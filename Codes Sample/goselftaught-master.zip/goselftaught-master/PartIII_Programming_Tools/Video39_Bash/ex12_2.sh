$ rmdir tstp
