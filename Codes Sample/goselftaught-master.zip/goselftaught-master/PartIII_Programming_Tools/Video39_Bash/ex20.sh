sudo echo Hello, World!
