$ echo Hello, World!
