$ ls
