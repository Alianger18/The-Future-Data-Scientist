$ touch .self_taught
