$ ls -author
