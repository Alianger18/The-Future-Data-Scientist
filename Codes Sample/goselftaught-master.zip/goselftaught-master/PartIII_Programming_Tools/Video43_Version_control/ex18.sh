$ git log
