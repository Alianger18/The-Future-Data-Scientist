$ git clone [repository_url]
