$ git commit -m "my first commit"
