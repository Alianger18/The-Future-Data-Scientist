$ git reset hangman.py
