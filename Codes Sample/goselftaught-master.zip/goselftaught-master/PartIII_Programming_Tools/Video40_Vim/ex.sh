vim data.txt
