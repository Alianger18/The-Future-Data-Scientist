pip uninstall flask
