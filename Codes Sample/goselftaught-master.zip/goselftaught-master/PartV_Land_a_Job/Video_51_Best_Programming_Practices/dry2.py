def print_string(a_string):
    for i in range(10):
        print(a_string)
