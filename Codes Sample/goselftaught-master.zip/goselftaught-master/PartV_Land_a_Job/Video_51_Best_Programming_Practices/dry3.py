def print_string(a_string, x):
    for i in range(x):
        print(a_string)
