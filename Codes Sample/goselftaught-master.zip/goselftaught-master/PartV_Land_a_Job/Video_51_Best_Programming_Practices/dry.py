for i in range(10):
    print("foo")
    
for i in range(10):
    print("bar")
    
for i in range(10):
    print("none")
