ivan = """In place of death there was light."""

ivan[0:17]
ivan[17:33]
