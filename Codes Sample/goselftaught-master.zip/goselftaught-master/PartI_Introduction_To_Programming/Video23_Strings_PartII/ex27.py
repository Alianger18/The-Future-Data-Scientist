'She said \"Surely.\"'
