"Bat" in "Cat in the hat."
