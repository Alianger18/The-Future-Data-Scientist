"Cat" in "Cat in the hat."
