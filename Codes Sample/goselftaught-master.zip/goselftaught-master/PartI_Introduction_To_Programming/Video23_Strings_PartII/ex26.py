"She said \"Surely.\""
