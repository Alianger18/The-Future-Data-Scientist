equ = "All animals are equal."
equ = equ.replace("a", "@")
print(equ)
