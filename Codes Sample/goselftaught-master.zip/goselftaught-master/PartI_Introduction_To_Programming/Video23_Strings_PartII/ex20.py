"animals".index("m")
