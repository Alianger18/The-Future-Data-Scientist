"Potter" not in "Harry"
