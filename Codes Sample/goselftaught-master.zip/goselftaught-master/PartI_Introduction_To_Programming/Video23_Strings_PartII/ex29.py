'She said "Surely."'
