"She said "Surely.""
