ivan = """In place of death there was light."""

ivan[17:]
