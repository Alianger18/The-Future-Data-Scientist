"Self-Taught"

"Self-Taught
