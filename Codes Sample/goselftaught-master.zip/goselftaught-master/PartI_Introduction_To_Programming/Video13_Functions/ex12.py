def f(x):
    return x * 2

x = f(3)
print(x)
