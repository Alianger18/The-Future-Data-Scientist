def even_odd(n):
    if n % 2 == 0:
        print("n is even.")
    else:
        print("n is odd.")


even_odd(10)
even_odd(11)
even_odd(12)
