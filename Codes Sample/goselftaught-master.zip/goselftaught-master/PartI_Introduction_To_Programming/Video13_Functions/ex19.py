def f(x=2):
    return x ** x
