n = 12
if n % 2 == 0:
    print("n is even.")
else:
    print("n is odd.")


n = 11
if n % 2 == 0:
    print("n is even.")
else:
    print("n is odd.")


n = 10
if n % 2 == 0:
    print("n is even.")
else:
    print("n is odd.")
