import random


random.randint(0,100)
