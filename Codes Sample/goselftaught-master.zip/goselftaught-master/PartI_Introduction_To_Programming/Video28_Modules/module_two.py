import module_one


module_one.print_hello()
