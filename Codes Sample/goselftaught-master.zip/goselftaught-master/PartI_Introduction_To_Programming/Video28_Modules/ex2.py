import statistics

# mean
nums = [1, 5, 33, 12, 46, 33, 2]
statistics.mean(nums)


# median
statistics.median(nums)


# mode
statistics.mode(nums)
