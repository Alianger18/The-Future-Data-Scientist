not 1 == 1 and 2 == 2
