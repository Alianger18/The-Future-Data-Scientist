1 == 1 and 2 == 2 and 3 == 3
