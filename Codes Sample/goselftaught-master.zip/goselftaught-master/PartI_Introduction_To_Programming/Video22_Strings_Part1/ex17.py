words = ["The", "fox", "jumped", "over", "the", "fence", "."]
one_string = " ".join(words)
one_string
