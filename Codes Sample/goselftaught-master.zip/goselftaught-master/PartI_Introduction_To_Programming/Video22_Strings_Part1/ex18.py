s = "	the	" 	
s = s.strip()
