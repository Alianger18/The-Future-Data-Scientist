"cat" + "in" + "hat"
