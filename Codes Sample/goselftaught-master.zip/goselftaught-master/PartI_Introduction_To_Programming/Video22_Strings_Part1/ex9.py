"SO IT GOES.".lower()
