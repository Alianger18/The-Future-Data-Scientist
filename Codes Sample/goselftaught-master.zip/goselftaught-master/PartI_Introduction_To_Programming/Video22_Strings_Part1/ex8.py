"We hold these truths...".upper()
