"four score and...".capitalize()
