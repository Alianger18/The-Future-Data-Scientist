author = "Kafka"
author[-1]
