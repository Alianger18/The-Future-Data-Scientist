"""I jumped over the puddle. It was 12 feet!""".split(".")
