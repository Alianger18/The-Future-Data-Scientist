a_string = "Hello, World!"
a_string

boolean = True
boolean
