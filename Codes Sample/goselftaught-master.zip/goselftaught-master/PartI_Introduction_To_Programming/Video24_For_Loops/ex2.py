shows = ["GOT", "Narcos", "Vice"]
for show in shows:
    print(show)
