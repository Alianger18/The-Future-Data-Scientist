tv = ["Got", "Narcos", "Vice"]
coms = ["Arrested Development", "friends", "Always Sunny"]
all_shows = []


for show in tv:
    show = show.upper()
    all_shows.append(show)


for show in coms:
    show = show.upper()
    all_shows.append(show)


print(all_shows)
