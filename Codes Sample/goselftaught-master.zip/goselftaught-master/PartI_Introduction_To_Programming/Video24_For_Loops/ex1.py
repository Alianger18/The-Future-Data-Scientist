name = "Ted"
for character in name:
    print(character)
