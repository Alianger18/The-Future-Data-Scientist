coms = ("A. Development", "Friends", "Always Sunny")
for show in coms:
    print(show)
