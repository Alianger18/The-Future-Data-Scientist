x = 19
if x == 10:
    print("x is 10.")
elif x % 2 == 0:
    print("x is even.")
elif x == 19:
    print("x is 19.")
else:
    print("x is not 10.")
