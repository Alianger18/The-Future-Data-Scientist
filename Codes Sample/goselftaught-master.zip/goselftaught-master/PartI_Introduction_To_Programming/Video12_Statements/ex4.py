x = 12
if x == 10:
    print("x is 10.")
elif x % 2 == 0:
    print("x is even.")
else:
    print("x is not 10.")
