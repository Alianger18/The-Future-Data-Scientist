x = 11
if x == 10:
    print("x is 10.")
else:
    print("x is not 10.")
