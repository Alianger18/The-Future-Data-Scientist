y = 12

if y == 12:
    print("y is 12")

if y % 2 != 0:
    print("y is even.")
else:
    print("y is odd.")
