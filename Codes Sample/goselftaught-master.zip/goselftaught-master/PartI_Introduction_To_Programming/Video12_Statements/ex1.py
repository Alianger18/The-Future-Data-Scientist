x = 10
if x == 10:
    print("x is 10.")
