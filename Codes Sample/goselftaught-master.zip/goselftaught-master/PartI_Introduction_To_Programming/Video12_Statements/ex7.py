x = 10
y = 11
if x == 10:
    if y == 11:
        print("x is 10 and y is 11.")
