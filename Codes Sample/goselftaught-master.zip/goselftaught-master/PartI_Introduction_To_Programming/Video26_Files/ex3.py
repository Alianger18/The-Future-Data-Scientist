with open("st.txt", "r") as f:
    print(f.read())
