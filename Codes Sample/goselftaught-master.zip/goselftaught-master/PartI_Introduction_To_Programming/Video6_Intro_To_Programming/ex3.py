print("Hi!")
print("Hola!")
