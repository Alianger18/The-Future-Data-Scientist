# this is a comment
print("Hi!")
print("Hola!")
print("Hello!")
