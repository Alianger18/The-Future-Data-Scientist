import math

# calculate rectangle diagonal

l = 4
w = 10
d = math.sqrt(l**2+w**2)
