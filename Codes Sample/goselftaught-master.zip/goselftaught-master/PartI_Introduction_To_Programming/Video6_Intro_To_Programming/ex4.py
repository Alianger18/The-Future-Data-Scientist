print("Hi!")
print("Hola!")
print("Hello!")
