def f():
    x = 1
    y = 2
    z = 3
    print(x)
    print(y)
    print(z)


f()
