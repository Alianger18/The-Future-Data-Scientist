my_tuple = ()
my_tuple
