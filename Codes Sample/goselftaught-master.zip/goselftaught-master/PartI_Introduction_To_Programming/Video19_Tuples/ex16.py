my_tuple = tuple()
my_tuple
