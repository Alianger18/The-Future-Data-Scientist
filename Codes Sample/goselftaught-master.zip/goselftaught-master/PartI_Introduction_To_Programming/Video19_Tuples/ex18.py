dys = ("1984", "Brave New World", "Fahrenheit 451")
dys[1] = "Handmaid's Tale"
