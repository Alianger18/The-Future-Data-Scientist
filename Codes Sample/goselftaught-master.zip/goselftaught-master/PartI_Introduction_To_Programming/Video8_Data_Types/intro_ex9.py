"Hello, World!"

"Python"

"Self-Taught"
