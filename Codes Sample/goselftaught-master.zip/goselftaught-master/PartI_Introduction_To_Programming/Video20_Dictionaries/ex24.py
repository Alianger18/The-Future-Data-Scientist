fruits = {"Apple": "Red", "Banana": "yellow"}
fruits
