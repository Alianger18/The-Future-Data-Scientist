facts = dict()
facts["code"] = "fun"
facts["Bill"] = "Gates"
facts["founded"] = 1776
facts["code"]
facts["Bill"]
facts["founded"]
