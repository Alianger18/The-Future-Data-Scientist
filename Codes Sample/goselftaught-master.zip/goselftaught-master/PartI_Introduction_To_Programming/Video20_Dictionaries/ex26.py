bill = {"Bill Gates": "charitable"}

"Bill Gates" in bill
