bill = {"Bill Gates": "charitable"}

"Bill Doors" not in bill
