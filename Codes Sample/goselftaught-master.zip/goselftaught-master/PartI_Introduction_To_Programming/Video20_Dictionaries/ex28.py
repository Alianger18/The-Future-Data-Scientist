books = {"Dracula": "Stoker",
         "1984": "Orwell",
         "The Trial": "Kafka"}


del books["The Trial"]

books
