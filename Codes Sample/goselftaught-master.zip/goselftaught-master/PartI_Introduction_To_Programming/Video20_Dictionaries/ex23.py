my_dict = {}
my_dict
