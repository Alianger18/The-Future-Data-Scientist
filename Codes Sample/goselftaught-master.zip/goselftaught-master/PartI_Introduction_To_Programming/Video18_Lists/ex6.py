fruit = ["Apple", "Orange", "Pear"]
fruit.append("Banana")
fruit.append("Peach")
fruit
