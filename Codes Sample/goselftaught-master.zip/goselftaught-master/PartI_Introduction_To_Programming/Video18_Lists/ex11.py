colors = ["blue","green","yellow"]
colors
item = colors.pop()
item
colors
