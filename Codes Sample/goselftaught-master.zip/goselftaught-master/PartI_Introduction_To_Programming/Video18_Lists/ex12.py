colors1 = ["blue", "green", "yellow"]
colors2 = ["orange", "pink", "black"]
colors1 + colors2
