fruit = ["Apple", "Orange", "Pear"]
fruit[0]
fruit[1]
fruit[2]
