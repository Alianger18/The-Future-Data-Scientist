fruit = ["Apple", "Orange", "Pear"]
fruit
