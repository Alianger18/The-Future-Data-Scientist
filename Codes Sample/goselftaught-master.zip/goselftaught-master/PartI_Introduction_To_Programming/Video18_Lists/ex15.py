colors = ["blue","green","yellow"]
len(colors)
