eights = ["Edgar Allan Poe",
          "Charles Dickens"]


nines = ["Hemingway",
         "Fitzgerald",
         "Orwell",
         "Sinclair"]


authors = (eights, nines)
print(authors[0])
print(authors[1])
