class Orange:
    def __init__(self):
        print("Created!")
