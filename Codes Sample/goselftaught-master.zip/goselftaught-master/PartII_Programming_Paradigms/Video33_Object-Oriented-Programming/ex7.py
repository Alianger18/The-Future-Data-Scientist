mick = Person("Mick Jagger")
stan = Dog("Stanley",
           "Bulldog",
           mick)
print(stan.owner.name)
