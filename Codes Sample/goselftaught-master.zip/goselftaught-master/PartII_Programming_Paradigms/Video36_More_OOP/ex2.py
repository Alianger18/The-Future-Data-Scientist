class Lion:
   def __init__(self, name):
       self.name = name


lion = Lion("Dilbert")
print(lion)
