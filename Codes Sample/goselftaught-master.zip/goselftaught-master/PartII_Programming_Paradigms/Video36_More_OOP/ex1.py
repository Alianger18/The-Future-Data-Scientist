class Square:
    pass


print(Square)
