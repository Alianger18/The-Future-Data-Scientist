# https://gist.github.com/calthoff/b90a6c5cfe7a18f25f3f67c554580b13
shapes = [tr1, sw1, cr1]

for a_shape in shapes:
    a_shape.draw()
