type("Hello, World!")
type(200)
type(200.1)
