print("Hello, World!")
print(200)
print(200.1)
